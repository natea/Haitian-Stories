# Copyright (c) 2007-2009 The PyAMF Project.
# See LICENSE for details.

"""
Remoting tests.

@since: 0.1.0
"""
