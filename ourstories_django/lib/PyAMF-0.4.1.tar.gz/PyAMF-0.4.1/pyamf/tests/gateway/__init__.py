# Copyright (c) 2007-2009 The PyAMF Project.
# See LICENSE for details.

"""
Unit tests for Remoting gateways.

@since: 0.1.0
"""
