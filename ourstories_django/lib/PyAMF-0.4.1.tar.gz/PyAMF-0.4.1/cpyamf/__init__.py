# Copyright (c) 2007-2009 The PyAMF Project.
# See LICENSE for details.

"""
Python C-extensions for L{PyAMF<pyamf>}.

@since: 0.4
"""
